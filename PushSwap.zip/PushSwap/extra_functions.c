/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   extra_functions.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtorres- <dtorres-@student.42madrid.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/25 16:33:41 by dtorres-          #+#    #+#             */
/*   Updated: 2023/05/30 17:34:59 by dtorres-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

/*void	show_list(t_stack *l)
{
	t_node	*aux;

	aux = *l;
	while (aux != NULL)
	{
		ft_printf("%d\n", aux->nbr);
		aux = aux->next;
	}
}*/

int	is_ordered(t_stack l)
{
	t_node	*aux;

	aux = l;
	while (aux->next != NULL)
	{
		if (aux->nbr < aux->next->nbr)
			aux = aux->next;
		else
			return (0);
	}
	return (1);
}

void	order(t_stack *a, t_stack *b)
{
	*a = NULL;
	*b = NULL;
}

void	order_three(t_stack *a)
{
	if ((*a)->nbr > (*a)->next->nbr)
		sa(a, 0);
	if ((*a)->next->nbr > (*a)->next->next->nbr)
	{
		rra(a, 0);
		if ((*a)->nbr > (*a)->next->nbr)
			sa(a, 0);
	}
}

void	order_five(t_stack *a, t_stack *b)
{
	int	s_size;

	s_size = size(a);
	while (s_size > 3)
	{
		if ((*a)->nbr == find_min(a))
			pb(a, b);
		else if ((*a)->next->nbr == find_min(a)
				|| (*a)->next->next->nbr == find_min(a))
			ra(a, 0);
		else
			rra(a, 0);
		s_size = size(a);
	}
	order_three(a);
	while (!is_empty(b))
		pa(a, b, 0);

}

int     find_min(t_stack *l)
{
	t_node	*aux;
	int	i;

	aux = *l;
	i = aux->nbr;
	while (aux->next != NULL)
	{
		if (aux->next->nbr < i)
			i = aux->next->nbr;
		aux = aux->next;
	}
	return (i);
}
